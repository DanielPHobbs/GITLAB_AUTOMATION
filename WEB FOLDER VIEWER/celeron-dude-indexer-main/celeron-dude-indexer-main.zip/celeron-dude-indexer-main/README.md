# Celeron Dude Indexer / Simple Directory Index

This script lists all files in a directory and sub-directories on a pretty looking page. Demo. All icons are embedded into index.php so you can just drop this file anywhere you want. Some configurable options are available in index.php. 

## License

Do whatever you want with it, just don't sell it. Hahaha like anyone would buy this.

## Installation

Extract index.php from the zip file and drop it into any directory. If you want to add more icons, extract and run icon.php. Select the the icon GIF image and click on Encode. Instructions on how to add it to index.php will appear. 

## Release Date

1/18/05